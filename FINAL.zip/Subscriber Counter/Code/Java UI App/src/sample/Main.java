package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.*;
import java.util.UUID;
import static javafx.scene.layout.Region.USE_COMPUTED_SIZE;

public class Main extends Application {

    public MqttClient mqttClient;
    public static IMqttClient publisher;

    @Override
    public void start(Stage primaryStage) throws Exception{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("sample.fxml"));
        Parent root = loader.load();

        String publisherId = UUID.randomUUID().toString();
        publisher = new MqttClient("tcp://broker.hivemq.com:1883", publisherId);
        MqttConnectOptions options = new MqttConnectOptions();
        options.setAutomaticReconnect(true);
        //options.setCleanSession(true);
        options.setConnectionTimeout(10);
        publisher.connect(options);

        primaryStage.setTitle("US Subscriber Counter");
        primaryStage.setScene(new Scene(root, USE_COMPUTED_SIZE, USE_COMPUTED_SIZE));
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
